# iOS / OSX Metal example

## Introduction

This example shows how to integrate Dear ImGui with Metal. It is based on the "cross-platform" game template provided with Xcode as of Xcode 9.

(NB: you may still want to use GLFW or SDL which will also support Windows, Linux along with OSX.)

